package com.StepDefinitions;

import static org.testng.Assert.assertEquals;


import static org.testng.Assert.assertTrue;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;


import com.Pages.AddtoCartPage;
import com.Pages.ConfirmOrderPage;
import com.Pages.HomePage;
import com.Pages.LoginPage;
import com.Pages.LogoutPage;
import com.Pages.RemovefromCart;
import com.Pages.SearchPage;
import com.Utilities.ConfigReader;


import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;


public class LoginSteps {
	WebDriver driver;
	LoginPage loginpage;
	HomePage homepage;
	SearchPage searchpage;
	AddtoCartPage cartpage;
	RemovefromCart removecartpage;
	ConfirmOrderPage orderpage;
	LogoutPage logoutpage;
	public static String url; //to get url
    public String br;
//    public ResourceBundle rb; // for reading properties file
//    public String br; //to store browser name
//    public String url; //to get url
  
    public Logger logger=LogManager.getLogger(LoginSteps.class); //for logging
//    public FileHandler filehandler;
//    public java.util.logging.Logger logger1;
    
    /////////////////////before starting of every scenario//////////////////////////////////
    @Before(order = 1)
    public void setup() throws IOException    //Junit hook - executes once before starting
    {
      //  System.setProperty("java.util.logging.SimpleFormatter.format","[%1$tF %1$tT] [%4$-7s] %5$s %n");
// 	   logger1 = java.util.logging.Logger.getLogger(LoginSteps.class.getName());
// 	   filehandler = new FileHandler("logs/automation123.log");
//        logger1.addHandler(filehandler);
        
        //Reading config.properties (for browser)- Appraoch1
        //rb=ResourceBundle.getBundle("config");
        //br=rb.getString("browser");
        
        //Reading config.properties (for browser)- Approach2
        File src = new File(".\\resources\\config.properties");
 		FileInputStream fis = new FileInputStream(src);
 		Properties pro = new Properties();
 		pro.load(fis);
 		br = pro.getProperty("browser");
 		url=pro.getProperty("petstoreurl");
         //logger.info("****************************");
    }
    
 	
 	@Before(order = 2)
 	public void broswer_is_open() {
 	    System.out.println("browser opening...");
 	   if(br.equals("chrome"))
       {
	       WebDriverManager.chromedriver().setup();
          driver=new ChromeDriver();
        			///////////
       }
       else if (br.equals("firefox")) {
       	WebDriverManager.firefoxdriver().setup();
       	  driver=new FirefoxDriver();
           		////////////
       }
       else if (br.equals("edge")) {
       	WebDriverManager.edgedriver().setup();
       	  driver=new EdgeDriver();
       
       }

 	    driver.get(url);
 	    driver.manage().window().maximize();
 		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
 		
 	}
 	/////////////////////////////////////After completion of every scenario/////////////////////////////////////
 	@After
 	public void tearDown(Scenario scenario) {
 		System.out.println("Scenario status==>"+scenario.getStatus());
// 		if(scenario.isFailed()) {
// 			System.out.println("Before capturing screenshot");
// 			File screenshot=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
// 			scenario.attach(screenshot.getAbsolutePath(), "image/png", scenario.getName());
// 			System.out.println("After capturing screenshot");
// 		}
 		
 		if (scenario.isFailed()) {
 		    byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
 		    String screenshotName = "failedScenarioScreenshot.png";

 		    // Save the screenshot as a file
 		    try (OutputStream os = new FileOutputStream(screenshotName)) {
 		        os.write(screenshot);
 		    } catch (IOException e) {
 		        e.printStackTrace();
 		    }

 		    // Attach the file to the scenario
 		    scenario.attach(screenshot, "image/png", "Failed Scenario Screenshot");
 		}

 		
 		driver.quit();
 	}

    
  
  	/////////////////////////////////login page//////////////////////////////////////////////
	@Given("user is on login page")
	public void user_is_on_login_page() throws InterruptedException {
		loginpage=new LoginPage(driver);
	    System.out.println("User is on login page");
	    loginpage.enterStore();
	    logger.info("User enter into the petstore");
	    loginpage.enterLogin();
	    logger.info("Clicked on signin button");
	    Thread.sleep(2000);
	}
	@When("user enters username as {string} and password as {string}")
	public void user_enters_username_as_and_password_as(String username, String password) throws InterruptedException {
		 System.out.println("User enters username and password");
		    //username
		    loginpage.enterUsername(username);
		    logger.info("User provided username");
		    //password
		    loginpage.enterPassword(password);
		    logger.info("User provided password");
		   Thread.sleep(2000);
	}
	@When("click on login button")
	public void click_on_login_button() {
		System.out.println("User clicks on login button");
		   loginpage.enterLogon();
		   logger.info("User clicked on signon button");
	}
	//-------------------------------------home page-----------------------------------
	@Then("user sees message as {string}")
	public void user_sees_message_as(String expectedMessage) throws InterruptedException {
		   homepage=new HomePage(driver);
		   System.out.println("validate the user is navigated to home page");
		   
		   if(expectedMessage.contains("Welcome")) {
		   System.out.println("User provides valid credentials...");
		   String welcome_text= homepage.verifyWelcomeContent();
		   logger.info("Login is sucessfull");
		   assertTrue(welcome_text.equals(expectedMessage),"Verfication sucess....");
		   }
		   else if(expectedMessage.contains("Invalid username or password")){
		   System.out.println("User provides invalid credentials...");
		   logger.error("Login failed");
		   String error_msg=homepage.errorInvalidCredentials();
		   assertEquals(error_msg,expectedMessage,"Invalid crdentials");
		  
		   }
		   else {
			   System.out.println("User provides empty credentials...either username or password");
			   logger.error("Login failed");
			   String error_msg=homepage.errorEmptyCredentials();
			   assertEquals(error_msg, expectedMessage,"Empty crdentials");
		   }
		   Thread.sleep(3000);
		   //driver.quit();
	}
	
	//----------------------------------------search page---------------------------------------------
	@Given("user enters empty text as {string}")
	public void user_enters_empty_text(String empty) {
	   searchpage=new SearchPage(driver);
	   searchpage.searchItem(empty);
	   logger.info("User enters empty text on search box");
	}
	@Then("user gets a error message")
	public void user_gets_a_error_message() {
	   WebElement actual_error= searchpage.searchError();
	   String expected_error="Please enter a keyword to search for, then press the search button.";
	   if(actual_error.isDisplayed()) {
		   logger.error("User gets an error message as "+actual_error);
		   assertEquals(searchpage.searchError().getText(), expected_error,"Verification passed..");
	   }
	   else {
		   assertTrue(false);
	   }
	   
	}

	@Given("user enters text as {string}")
	public void user_enters_text_as(String item) {
		searchpage=new SearchPage(driver);
		searchpage.searchItem(item);
		logger.info("User enters the product name");
	}
	@Given("user clicks on search button")
	public void user_clicks_on_search_button() throws InterruptedException {
	    searchpage.clickSearch();
	    logger.info("User clicked on search button");
	    Thread.sleep(3000);
	}
	@Then("user should navigated to the product and validate the product")
	public void user_should_navigated_to_the_particular_product() {
	   boolean validate= searchpage.productId();
	   if(validate) {
		   logger.info("Product details are displayed");
		   assertTrue(validate, "search product is validated sucessfully");
	   }
	   else {
		   logger.error("Search details are not found");
		   assertTrue(validate, "failed....");
	   }
	}
	

	//-------------------------------------------add to cart page-----------------------------------------
	@Given("user selects a product")
	public void user_selects_a_product() {
		cartpage=new AddtoCartPage(driver);
		cartpage.selectItem().click();
		logger.info("User enters the product name");
		
	}
	@When("user click on add to cart for the product")
	public void user_click_on_add_to_cart_for_the_product() throws InterruptedException {
		cartpage.cartItem().click();
		 logger.info("Selects the product");
		Thread.sleep(2000);
		cartpage.addtoCart().click();
		 logger.info("Clicked on AddtCart button");
		Thread.sleep(2000);
	}
	@Then("product is added to the cart")
	public void product_is_added_to_the_cart() {
	    System.out.println("Waiting for vaildation in next step...");
	}
	@Then("validate the product is sucessfullly added to the cart")
	public void validate_the_product_is_sucessfullly_added_to_the_cart() {
		if(cartpage.checkCart().isDisplayed()) {
			logger.info("Product is sucessfully added to the cart");
			Assert.assertTrue(true);
			System.out.println("product is added to the cart....");
		}
		else {
			 logger.info("Products gets an failure");
			Assert.assertTrue(false);
			//screenshootsMethod(driver,"addtoCart");
		    System.out.println("product is not added to the cart...");
		}
	}
	
	//------------------------------------remove from cart page----------------------------------
	@When("user click on remove item from the cart")
	public void removeFromCart() throws InterruptedException {
		removecartpage=new RemovefromCart(driver);
		 
		removecartpage.removefromCart().click();
		logger.info("User clicked on remove from cart button");
	}
	@Then("Item is removed from the cart and validate it")
	public void validateRemoveFromCart() {
	    WebElement validateCart= removecartpage.validateCart();
	    if(validateCart.isDisplayed()) {
	    	logger.info("Product removed from cart");
	    	assertTrue(true, "Verification sucess...");
	    }
	    else {
	    	 logger.error("Remove cart page is failed");
	    	assertTrue(false, "Failed...");
	    }
	}
	
	//--------------------------confirm order page----------------------------------------------
	@Given("user update the cart")
	public void user_update_the_cart() throws InterruptedException {
		orderpage=new ConfirmOrderPage(driver);
		Thread.sleep(2000);
		orderpage.selectItem().click();
		logger.info("User selects a product");
		Thread.sleep(3000);
		orderpage.addtoCart().click();
		logger.info("User added the product to the cart");
		orderpage.updateCart().click();
		logger.info("Clicked on update cart");
	}
	@When("user click on proceed to checkout")
	public void user_click_on_proceed_to_checkout() throws InterruptedException {
	    orderpage.checkOutBtn().click();
	    logger.info("Proceed to checkout order");
	    Thread.sleep(2000);
	}
	@When("user provide the shipping address")
	public void user_provide_the_shipping_address() throws InterruptedException {
		Thread.sleep(2000);
		//validate address
		String name=orderpage.validateAddress().getText();
		System.out.println(name);
		if(orderpage.validateAddress().isDisplayed()) {
			logger.info("Details are validated sucessfully");
			assertTrue(true, "Address verifed...");
		}
		else {
			 logger.error("Details are not verified ");
			assertTrue(false, "Failed...");
		}
		//same billing address
	   orderpage.pressContinue().click();
	   logger.info("Clicked on continue button");
	   
	}
	@When("click on confirm order")
	public void click_on_confirm_order() throws InterruptedException {
	    orderpage.Confirmbtn().click();
	    logger.info("Go for confirmation order");
	    Thread.sleep(2000);
	}
	@Then("order is confirmed and user receives the order details")
	public void order_is_confirmed_and_user_receives_the_order_details() {
		String verifyorder=orderpage.verifyCheckout().getText();
		if(verifyorder.equalsIgnoreCase("Thank you, your order has been submitted.")) {
			System.out.println(verifyorder);
			logger.info("order is places sucessfully");
			Assert.assertTrue(true);
			
		}
		else {
			System.out.println("Checkout process failed");
			 logger.error("order is failed");
			Assert.assertTrue(false);
			//screenshootsMethod(d,"checkoutProcess");
			
		}
	}
	@Then("validate order details")
	public void validate_order_details() {
		WebElement orderid=orderpage.orderID();
	   boolean orderid_check=orderid.isDisplayed();
	   if(orderid_check) {
		   logger.info("order detailes are verified..");
		   assertTrue(orderid_check, "The order id details are verified...");
		   System.out.println("The order id details are "+orderid.getText());
	   }
	   else {
		   logger.error("Order id details are not provided");
		   assertTrue(orderid_check, "The order details are not provided....");
	   }
	}
	//----------------------------------logoutpage-----------------------------------------
	@Given("user clicks on Sign Out button")
	public void user_clicks_on_sign_out_button() throws InterruptedException {
	    logoutpage=new LogoutPage(driver);
	    logoutpage.clickLogoutButton().click();
		Thread.sleep(2000);
	}
	@Then("user is signout from the website")
	public void user_is_signout_from_the_website() throws InterruptedException {
		Thread.sleep(2000);
		if(!(logoutpage.accountProfile().isDisplayed())) {
			Assert.assertTrue(false);
			    
		}else {
			Assert.assertTrue(true);
			System.out.println("Logout successful....!");
		}
	}
	
	

}

	

