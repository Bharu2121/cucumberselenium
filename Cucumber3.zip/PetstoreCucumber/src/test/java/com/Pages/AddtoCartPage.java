package com.Pages;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
public class AddtoCartPage {
	WebDriver driver;

	public AddtoCartPage(WebDriver driver) {
		//super();
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}
	@FindBy(xpath = "//*[@id=\"QuickLinks\"]/a[4]")
	WebElement selectitem;
	public WebElement selectItem(){
		return selectitem;
	}
	@FindBy(xpath = "//*[@id=\"Catalog\"]/table/tbody/tr[2]/td[1]/a")
	WebElement cartitem;
	public WebElement cartItem(){
		return cartitem;
	}
	@FindBy(linkText = "Add to Cart")
	WebElement addtocart;
	public WebElement addtoCart(){
		return addtocart;
	}
	@FindBy(xpath = "/html/body/div[2]/div[2]/div[1]/form/table/tbody/tr[2]/td[3]")
	WebElement checkcart;
	public WebElement checkCart(){
		return checkcart;
	}


}
