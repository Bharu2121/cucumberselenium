package com.Pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
public class LogoutPage {
	WebDriver driver;
	public LogoutPage(WebDriver driver) {
		//super();
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}
	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[2]")
	WebElement logoutbtn;
	public WebElement clickLogoutButton(){
		return logoutbtn;
	}
	@FindBy(xpath = "//*[@id=\"MenuContent\"]/a[3]")
	WebElement accountbtn;
	public WebElement accountProfile(){
		return accountbtn;
	}
	
}
