package com.Pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

public class RemovefromCart {
	WebDriver driver;

	public RemovefromCart(WebDriver driver) {
		//super();
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 30), this);
	}
	
	@FindBy(linkText = "Remove")
	WebElement removefromCart;
	public WebElement removefromCart() {
		 return removefromCart;
	}
	
	@FindBy(xpath  = "*//b[text()='Your cart is empty.']")
	WebElement validate_cart;
	public WebElement validateCart() {
		 return validate_cart;
	}
	
	
}
