package com.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigReader {
	private  Properties prop;
	
	
	public Properties intializedProperties() throws IOException{
		  //Reading config.properties (for browser)- Approach2
		this.prop = new Properties();
       // File src = new File(".\\resources\\config.properties");
 		
 		FileInputStream fis;
 		try {
 			fis = new FileInputStream(".\\resources\\config.properties");
 			prop.load(fis);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prop;
	}
	public String getBrowserName() {
		String browser=prop.getProperty("browser");
		if (prop == null) {
            try {
            	intializedProperties();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
		return browser;
	}
	public String getUrl() {
		String url=prop.getProperty("petstoreurl");
		return url;
	}
}
